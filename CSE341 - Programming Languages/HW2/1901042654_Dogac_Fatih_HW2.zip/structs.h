typedef struct int_list{

	char* name;
	int val;
	struct int_list* next;

}int_list;


typedef struct double_list{

	char* name;
	double dbVal;
	struct double_list* next;

}double_list;
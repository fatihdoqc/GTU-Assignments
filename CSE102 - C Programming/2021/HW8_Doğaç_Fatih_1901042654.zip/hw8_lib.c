/*
** hw8_lib.c:
**
** The source file implementing library functions.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.04.22.19.55
** 
*/

#include <stdio.h>
#include "hw8_lib.h"

#define WORDSIZE 1

void initialize_maze(cell_type maze[8][8] , int x , int y);
void print_maze(cell_type maze[8][8] , int x , int y);
int is_valid(cell_type maze[8][8] , int x , int y , move_type move);
void find_player(cell_type maze[8][8] , int *x , int *y , cell_type player );


void delete_words (FILE* infid, FILE* outfid, char* words_to_delete[WORDSIZE],  int number_of_words)
{
	int i;
}


void clean_file(char* infile, char * outfile, char* words_to_delete[WORDSIZE], int number_of_words)
{
	FILE* infid;
	FILE* outfid;
	infid = fopen(infile,"r");
	outfid = fopen(outfile , "a");
	delete_words (infid, outfid, words_to_delete, number_of_words);
	printf("TO BE IMPLEMENTED\n");
}
void print_maze(cell_type maze[8][8] , int x , int y){
	if(x == 7 && y == 7){				/* Prints the last unchecked tile. */
		printf("%d\n",maze[x][y]);
		printf("\n\n");

		return;
	}

	printf("%d\t",maze[x][y]);			/* Printing the corresponding maze tile.*/

	if(y == 7){							/* End of the row. */
		printf("\n");
		print_maze(maze , x+1 , 0);
	}
	else {								/* Shifting to the right. */
		print_maze(maze , x , y+1);
	}
}
void find_player(cell_type maze[8][8] , int *x , int *y , cell_type player ){

	if(maze[*x][*y] == player){ /* It is the player's location. */
		return;
	}
	if(*y == 7){				/* End of the row and player is not in that row. */
		*x = *x + 1;
		*y = 0;					/* Returning to start position of the row. */
		find_player(maze , x, y , player);
	}
	else{
		*y = *y + 1;			/* Shifting to right. */
		find_player(maze , x , y ,player);
	}


}
int is_valid(cell_type maze[8][8] , int x , int y , move_type move){

	int check = 1;

	if( (x < 0 || y < 0 || x > 7 || y > 7) || maze[x][y] == cell_wall ){ /* Invalid positions. */
		return 0;
	}

	if(move == move_left){
		check = is_valid(maze , x , y - 1 , move_invalid);
		return check;
	}
	else if(move == move_right){
		check = is_valid(maze , x , y + 1 , move_invalid);
		return check;
	}
	else if(move == move_up){
		check = is_valid(maze , x-1 , y , move_invalid);
		return check;
	}
	else if(move == move_down){
		check = is_valid(maze , x+1 , y , move_invalid);
		return check;
	}
}
void initialize_maze(cell_type maze[8][8] , int x , int y ){

	if(x == 7 && y == 7){				/* End of the maze. */
		maze[x][y] = cell_wall;
		return;
	}
	else if(x == 1 && y == 1){			/* P1 */
		maze[x][y] = cell_p1;
	}
	else if(x == 6 && y == 1){			/* P2 */
		maze[x][y] = cell_p2;
	}
	else if(x == 6 && y == 6){			/* Target. */
		maze[x][y] = cell_target;
	}
	else if( (y == 1 && (x != 0 && x != 7) ) || ( x == 2 && (y != 0 && y != 7) ) || (y == 6 && (x != 0 && x != 7) ) ){ 
		maze[x][y] = cell_free;			/* Road.*/
	}
	else{
		maze[x][y] = cell_wall;			/* Walls. */
	}
	
	if(y == 7){							/* Inıtializing the next row. */
		initialize_maze(maze , x+1 , 0);
	}
	else{								/* Initializing the next column of the current row. */
		initialize_maze(maze , x , y+1);
	}
}
int maze_move(cell_type maze[][8], cell_type player, move_type move)
{
	int x , y;

	find_player(maze , &x , &y , player); /* Recorded the player's position to the x and y. */
	print_maze(maze , 0 , 0);

	if(is_valid(maze , x , y , move)){

		if(move == move_left){
			maze[x][y] = cell_free;			/* Returning the player's position to what was it before. */

			if(maze[x][y-1] == cell_target){
				print_maze(maze , 0 , 0);
				return 1;
			}
			else{
				maze[x][y-1] = player;
				return 0;
			}
		}
		else if(move == move_right){
			maze[x][y] = cell_free;			/* Returning the player's position to what was it before. */

			if(maze[x][y+1] == cell_target){
				print_maze(maze , 0 , 0);
				return 1;
			}
			else{
				maze[x][y+1] = player;
				return 0;
			}
		}
		else if(move == move_up){
			maze[x][y] = cell_free;			/* Returning the player's position to what was it before. */

			if(maze[x-1][y] == cell_target){
				print_maze(maze , 0 , 0);
				return 1;
			}
			else{
				maze[x-1][y] = player;
				return 0;
			}
		}
		else if(move == move_down){
			maze[x][y] = cell_free;			/* Returning the player's position to what was it before. */

			if(maze[x+1][y] == cell_target){
				print_maze(maze , 0 , 0);
				return 1;
			}
			else{
				maze[x+1][y] = player;
				return 0;
			}
		}
	}
}


void towers_of_hanoi(char start_peg, char end_peg, char aux_peg, int n)
{
    if (n == 1)
    {
        printf("Move disk %d from peg %c to peg %c \n", n , start_peg , end_peg); 
        return;
    }
    towers_of_hanoi(start_peg, aux_peg, end_peg , n-1);	 /* Rearrange the disks position with the tower of hanoi algorithm. */
    printf("Move disk %d from peg %c to peg %c \n", n , start_peg , end_peg);
    towers_of_hanoi(aux_peg, end_peg, start_peg , n-1);
}

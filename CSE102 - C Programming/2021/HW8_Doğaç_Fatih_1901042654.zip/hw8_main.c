/*
** main.c:
**
** The test/driver program for the homework.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.04.22.19.55
** 
*/


#include <stdio.h>
#include <string.h>
#include "hw8_lib.h"

void test_clean_file () 
{
}


void test_maze_move ()
{
	cell_type maze[8][8];
	cell_type player = cell_p1;

	initialize_maze(maze , 0 ,0);

	maze_move(maze , player , move_down);
	maze_move(maze , player , move_right);
	maze_move(maze , player , move_left);
	maze_move(maze , player , move_up);
		
}


void test_towers_of_hanoi ()
{
	towers_of_hanoi('S' , 'E' , 'A' , 3);
}


/*
** main function for testing the functions...
**
*/
int main(void) {
	/*test_clean_file ();*/
	test_maze_move ();
	test_towers_of_hanoi ();
	return (0);
} /* end main */

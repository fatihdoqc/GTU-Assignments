/*
** hw2_lib.c:
**
** The source file implementing library functions.
**
*/

#include <stdio.h>
#include <math.h>
#include "hw2_lib.h"


int find_weekday_of_data(int day, int month, int year) 
{
	int m , y ,c , w , flag = 0;

	if(day < 1 || day > 31){
		printf("%s\n","Day cannot be lesser than 1 or greater than 31.\n ");
		return -1;
	}
	if(month < 1 || month > 12){
		printf("%s\n","Month cannot be lesser than one or greater than 12.\n ");
		return -1;
	}
	if(year < 1){
		printf("%s\n","Year cannot be lesser than one.\n ");
		return -1;
	}
	if(year % 400 == 0) {
     	flag = 1;
  	}
	else if(year % 4 == 0) {
	 	flag = 1;
	}

	if(month == 2 && flag != 1 && day > 29){
		if(flag == 1){
			printf("%s\n","Day cannot be greater than 29 in leap years in February.\n ");
			return -1;
		}
		else if(flag == 0){
			printf("%s\n","Day cannot be greater than 28 in leap years in February.\n ");
			return -1;
		}
		
	}
	if(month == 4 || month == 6 || month == 9 || month == 11){
		if(day > 30){
			printf("%s\n","Day cannot be greater than 30 for this month.\n ");
			return -1;
		}
	}

   	if(month > 2)
   	   m = month;    
  	 else {
  	    m = month + 12; /* for January and February, month will be 13 and 14 according to Zeller's algorithm. */ 
  	    year--;			/* Decreasing year by one for January and February. */			
  	 }
         
   	y = year % 100;   	/* Last two digit of the year. */ 
   	c = year / 100;  	/* First two digit of the year. */ 

  	w = (day + ((13 * ( m + 1) ) / 5) + y + ( y/4 ) + ( c/4 ) + (5*c) ); /* Zeller Algorithm */

	w = w % 7;	

	switch(w){
		case 0: /* Saturday */
			return 6;
		case 1:
			return 7;
		case 2:
			return 1;
		case 3:
			return 2;
		case 4:
			return 3;
		case 5:
			return 4;
		case 6:
			return 5;
	}
}
int day_number_of_date(int day , int month , int year){

	month = (month + 9) % 12; /* shifting the month and year values so the calendar starts from March.
	* That way program have to calculate only years. Not days per month */

	year = year - month/10;

	return (365*year) + (year/4) - (year/100) + (year/400) /* if year is a leap year , 
	c will erase the part after the comma.So there will only be an integer. */
	+ ((month*306 + 5) / 10 ) /* Since the calendar starts from March , this returns the days between March 1st and
	 "month"th month after March. */

	+ ( day - 1 ); /* Adding day value. */
}

int count_day_between_dates(int start_day, int start_month, int start_year, int end_day, int end_month, int end_year)
{
 	return 
 	day_number_of_date(end_day , end_month , end_year) - day_number_of_date(start_day , start_month , start_year);

}


double find_angle(double a, double b, double c)
{
   	double Vc = sqrt( ((b*b) + (a*a) - ((c*c) / 2)) / 2 ); /* Median of a triangle. */
   	double Vb = sqrt( ((c*c) + (a*a) - ((b*b) / 2)) / 2 ); /* Another median of a triangle. */

   	double small_triangle_b = (2*Vb/3); /* One of the sides next to the alpha. */
   	double small_triangle_c = (2*Vc/3);	/* The other side of the small triangle next to the alpha. */

   	/* cos teorem to find the angle */
   	double alpha = acos(((small_triangle_c * small_triangle_c) + 
   						 (small_triangle_b * small_triangle_b) - (a*a)) /
   						 ( 2*small_triangle_b*small_triangle_c));

   	return alpha;
}

void spam_character(char border){
	int i;

	
	for(i = 0; i<71; i++){
    	printf("%c", border);
    }
    
}

void print_tabulated(unsigned int r11, double r12, int r13, 
                     unsigned int r21, double r22, int r23, 
                     unsigned int r31, double r32, int r33, char border)
{
	int i , j;

	printf("\n");
	printf("\xe2\x8c\x9c");
	spam_character(border);
	printf("\xe2\x8c\x9d\n");

    printf("|\t%9s\t|\t%9s\t|\t%9s\t|\n","Row 101","Row ABCDEFG","Row XYZ123");
    spam_character(border);
    printf("\n");

    if(r13 > 0){
  	 	printf("|\t%9d\t|\t%9.3g\t|\t+%9d\t|\n", r11 , r12 , r13);
  	 }
  	 else{
  	 	printf("|\t%9d\t|\t%9.3g\t|\t%9d\t|\n", r11 , r12 , r13);
  	 }

}


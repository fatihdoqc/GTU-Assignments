package default_package;
/**
 * Interface for HashMaps
 * @author Fatih
 *
 * @param <K> Generic key type
 * @param <V> Generic value type
 */
public interface KWHashMap< K , V> {
	
	V get(Object key);
	boolean isEmpty();
	V put(K key, V value);
	V remove(Object key);
	int size();
}

/**
 * User or person interface.
 * @author Fatih
 *
 */
public interface Users {
	
	String getName();
	int getID();
	int getPassword();
	
	void setName(String s);
	void setID(int i);
	void setPassword(int i);
	
}

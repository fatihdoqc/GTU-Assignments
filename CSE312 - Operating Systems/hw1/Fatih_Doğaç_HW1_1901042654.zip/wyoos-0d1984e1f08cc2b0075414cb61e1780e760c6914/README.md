Open terminal in folder. Then run "make" and take the mykernel.iso and load it into your VM's storage.

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define N 4

typedef enum{
        up,
        down,
        left,
        right,
        unavailable,
}direction;

void show_table(int arr[N][N] , int size);
void initialize_board(int arr[N][N] , int size);
int win_check(int arr[N][N] , int size);
int play(direction dir , int x , int y , int arr[N][N] , int size);
direction is_playable(int x , int y , int arr[N][N] , int size);
void game();
void getInput(int *row , int *col , direction *dir);

void main(){
	
    srand(time(0));	
    game();
}
void game(){

    int arr[N][N] , row , col;
    direction dir;

    initialize_board(arr,N);

    while(win_check(arr , N) != 1){
        show_table(arr , N);
        getInput(&row , &col , &dir);
        if(play(dir,row,col,arr,N) == 0){
            printf("This move cannot be played. Please try again.\n");
        }
    }
    show_table(arr , N);
    printf("\nYou won.\n");
}
direction is_playable(int x , int y , int arr[N][N] , int size){

    if(x < 0 || y < 0 || x > size || y > size || arr[x][y] == size*size){ // Invalid move.
        return unavailable;
    }

    for(int i = 0; i< size ; i++){
        if(arr[x][(y+i) % size] == size*size){ // scanning through x axis.
            if( (y+i) >= size){ // if the empty tile cannot be found by going right.
                return left;    // Than it is in the left of the wanted tile.
            }
            else{
                return right;
            }
        }
        else if(arr[(x+i) % size][y] == size*size){ // scanning through y axis.
            if( (x+i) >= size ){    // if the empty tile cannot be found by going down.
                return up;          // Than it is below of the wanted tile.
            }
            else{
                return down;
            }
        }
    }

    return unavailable;
}
int play(direction dir , int x , int y , int arr[N][N] , int size){

    direction check_dir = is_playable(x , y , arr ,size);
    int temp_x , temp_y;

    if(check_dir == unavailable || check_dir != dir){
        return 0;
    }

    switch(dir){
        case 0: // Wanted tile is wanted to move up. 

            temp_x = (x - 1) ; // Will keep the empty tile.
            temp_y = y;

            while(1){
                if(arr[temp_x][temp_y] == size*size){ // Scanning the empty tile.
                    break;
                }
                temp_x--;;
            }
            for(int i = temp_x; i < x; i++){ // Shifting tiles until the wanted tile.
                arr[i][y] = arr[i+1][y];
            }

            arr[x][y] = size*size; // Replacing the empty tile.
            break;
        case 1: // Wanted tile is wanted to move down.
            temp_x = (x + 1) ;
            temp_y = y;

            while(1){
                if(arr[temp_x][temp_y] == size*size){ // Scanning the empty tile.
                    break;
                }
                temp_x++;
            }
            for(int i = temp_x; i > x; i--){ // Shifting tiles until the wanted tile.
                arr[i][y] = arr[i-1][y];
            }

            arr[x][y] = size*size; // Replacing the empty tile.
            break;
        case 2: // Wanted tile is wanted to move left.
            temp_x = x ;
            temp_y = y - 1;

            while(1){
                if(arr[temp_x][temp_y] == size*size){   // Scanning the empty tile.
                    break;
                }
                temp_y--;
            }
            for(int i = temp_y; i < y; i++){    // Shifting tiles until the wanted tile.
                arr[x][i] = arr[x][i+1];
            }

            arr[x][y] = size*size;  // Replacing the empty tile.
            break;
        case 3: // Wanted tile is wanted to move right.
            temp_x = x ;
            temp_y = y + 1;

            while(1){
                if(arr[temp_x][temp_y] == size*size){   // Scanning the empty tile.
                    break;
                }
                temp_y++;
            }

            for(int i = temp_y; i > y; i--){    // Shifting tiles until the wanted tile.
                arr[x][i] = arr[x][i-1];
            }

            arr[x][y] = size*size;  // Replacing the empty tile.
            break;
    }

    return 1;
}
void getInput(int *row , int *col , direction *dir){

    char temp_dir[10];

    printf("Your move (please type as 'row' 'col' 'direction' , type -1 to exit.) : ");
    
    scanf("%d",row);
    if(*row == -1){ // Exit call.
        exit(0);
    }
    scanf("%d %s",col,temp_dir);
    
    if(*row > N || *col > N || *row < 0 || *col < 0){ // Invalid input.
        printf("Bad input. Please try again.\n");
        getInput(row,col,dir);
    }

    if(strcmp(temp_dir , "up") == 0){
        *dir = 0;
    }
    else if(strcmp(temp_dir , "down") == 0){
        *dir = 1;
    }
    else if(strcmp(temp_dir , "left") == 0){
        *dir = 2;
    }
    else if(strcmp(temp_dir , "right") == 0){
        *dir = 3;
    }
    else{
        printf("Bad input. Please try again.\n");
        getInput(row,col,dir);
    }
}
int win_check(int arr[N][N] , int size){
    int counter = 1;
    for(int i = 0; i<size; i++){
        for(int j = 0; j<size; j++){

            if(arr[i][j] != counter){ // If the table isn't going by the order. Then user hasn't won yet.
                return 0;
            }
            counter++;
        }
    }
    return 1;
}
int is_include(int arr[N][N] , int size , int number){

    for(int i = 0; i<size; i++){
        for(int j = 0; j<size; j++){

            if(arr[i][j] == number){
                return 1;
            }
        }
    }
    return 0;

}
void initialize_board(int arr[N][N] , int size){
    int tile;

    for(int i = 0; i<size; i++){
        for(int j = 0; j<size; j++){

            while(1){
                tile = (rand() % (N*N) ) +1;            // If the random number is already in the array.
                if(is_include(arr , size , tile) == 0){ // Generate a new one until it is unique.
                    break;
                }
            }
         
            arr[i][j] = tile;
        }
    }
}
void show_table(int arr[N][N] , int size){

    printf("\n\t");

    for(int i = 0; i<size; i++){        // Column numbers.
        printf("\t%d\t",i);
    }
    printf("\n");

    for(int i = 0; i< size; i++){

        printf("\t");
        for(int k = 0; k< size ;k++){   // Upper frame.
            printf("|***************");
        }

        printf("|\n%d\t",i);
        for(int j = 0; j<size; j++){    
            if(arr[i][j] != (N*N)){     // Numbers.
                printf("|\t%d\t",arr[i][j]);
            }
            else{
                printf("|\t\t");
            }
        }
        printf("|\n\t");
        for(int l = 0; l<size; l++){    // End of the line.
            printf("|\t\t");
        }
        printf("|\n");
        
    }
    
    printf("\t");
    for(int k = 0; k< size ;k++){       // Lower frame.
        printf("|***************");
    }
    printf("|\n");
}


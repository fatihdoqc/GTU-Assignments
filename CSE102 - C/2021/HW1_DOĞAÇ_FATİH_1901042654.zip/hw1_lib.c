/*
** hw4_lib.c:
**
** The source file implementing library functions.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.03.03.20.16
** 
*/

#include <stdio.h>
#include "hw1_lib.h"


double integral3(double a0, double a1, double a2, double a3, double xs, double xe, double delta)
{
	if(delta > xe-xs){
		printf("Delta cannot be bigger than interval.\n");
		return 0;
	}

    int rectangle_count = (xe - xs) / delta;
    double sum = 0.0 , x , y;

    for(int i = 0; i< rectangle_count ; i++){

    	x = xs + i * delta;
    	y = ( (a0*x*x*x) + (a1*x*x) + (a2*x) + (a3) ); // equation
    	sum += delta * y;
    }
    return sum;
}


double integral4(double a0, double a1, double a2, double a3, double a4, double xs, double xe, double delta)
{
	if(delta > xe-xs){
		printf("Delta cannot be bigger than interval.\n");
		return 0;
	}

    int rectangle_count = (xe - xs) / delta;
    double sum = 0.0 , x , y;

    for(int i = 0; i< rectangle_count ; i++){

    	x = xs + i * delta;
    	y = (a0*x*x*x*x) + (a1*x*x*x) + (a2*x*x) + (a3*x) + a4; // equation
    	sum += delta * y;
    }
    return sum;
}


double root3(double a0, double a1, double a2, double a3, double xs, double xe)
{
	double i,eq; 
   	for(i = xs; i<=xe ; i += 0.01){ /* Starting from xs to the xe */ 

   		eq = (a0*i*i*i) + (a1*i*i) + (a2*i) + a3; // equation

   		if(eq > -0.01 && eq < 0.01 ){ // as close as possible to 0
   			return i;
   		}
   	}
}


double root4(double a0, double a1, double a2, double a3, double a4, double xs, double xe)
{
    double i , eq;
   	for(i = xs; i<=xe ; i += 0.01){ /* Starting from xs to the xe */ 

   		eq = (a0*i*i*i*i) + (a1*i*i*i) + (a2*i*i) + (a3*i) + a4; // equation

   		if( eq > -0.01 && eq < 0.01 ){ // as close as possible to 0
   			return i;
   		}
   	}
}

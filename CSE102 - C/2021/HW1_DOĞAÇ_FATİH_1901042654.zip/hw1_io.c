/*
** hw1_io.c:
**
** The source file implementing output functions.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.03.03.20.16
** 
*/


#include <stdio.h>
#include "hw1_io.h"


void write_polynomial3(double a0, double a1, double a2, double a3)
{
    if( a0 < 0){
		if(a0 < -0.9999 && a0 > -1.0001 ){  /* Handling the situation -1.00 */
			printf("-x^3",a0);
		}
    	else{ 								/* Handling the negative numbers */
			printf("%.2fx^3",a0);
		}
    }
    else{
    	if(a0 < 1.0001 && a0 > 0.9999){ 	/* Handling the situation +1.00 */
    		printf("x^3",a0);
		}
    	
    	else if(a0 != 0){					/* Handling the non-zero positive numbers */
    		printf("%.2fx^3",a0);
    	}
    }

    if( a1 < 0){
		if(a1 < -0.9999 && a1 > -1.0001 ){
			printf("-x^2",a1);
		}
		else{
			printf("%.2fx^2",a1);
		}
    	
    }
    else{
    	if(a1 < 1.0001 && a1 > 0.9999){
    		printf("x^2",a1);
		}
    	
    	else if(a1 != 0){
    		printf("%.2fx^2",a1);
    	}
    }

    if( a2 < 0){
		if(a2 < -0.9999 && a2 > -1.0001 ){
			printf("-x",a2);
		}
    	else{
			printf("%.2fx",a2);
		}
    }
    else{
    	if(a2 < 1.0001 && a2 > 0.9999){
    		printf("x",a2);
		}
    	
    	else if(a2 != 0){
    		printf("%.2fx",a2);
    	}
    }

    if(a3 < 0){
    	printf("%.2f",a3);
    }
    else{
    	if(a3 != 0){
    		printf("+%.2f",a3);
    	}
    }
    printf("\n");
}


void write_polynomial4(double a0, double a1, double a2, double a3, double a4)
{
    if( a0 < 0){
		if(a0 < -0.9999 && a0 > -1.0001 ){
			printf("-x^4",a0);
		}
    	else{
			printf("%.2fx^4",a0);
		}
    }
    else{
    	if(a0 < 1.0001 && a0 > 0.9999){
    		printf("x^4",a0);
		}
    	
    	else if(a0 != 0){
    		printf("%.2fx^4",a0);
    	}
    }

    if( a1 < 0){
		if(a1 < -0.9999 && a1 > -1.0001 ){
			printf("-x^3",a1);
		}
		else{
			printf("%.2fx^3",a1);
		}
    	
    }
    else{
    	if(a1 < 1.0001 && a1 > 0.9999){
    		printf("x^3",a1);
		}
    	
    	else if(a1 != 0){
    		printf("%.2fx^3",a1);
    	}
    }

    if( a2 < 0){
		if(a2 < -0.9999 && a2 > -1.0001 ){
			printf("-x^2",a2);
		}
    	else{
			printf("%.2fx^2",a2);
		}
    }
    else{
    	if(a2 < 1.0001 && a2 > 0.9999){
    		printf("x^2",a2);
		}
    	
    	else if(a2 != 0){
    		printf("%.2fx^2",a2);
    	}
    }

    if( a3 < 0){
		if(a3 < -0.9999 && a3 > -1.0001 ){
			printf("-x",a3);
		}
    	else{
			printf("%.2fx",a3);
		}
    }
    else{
    	if(a3 < 1.0001 && a3 > 0.9999){
    		printf("x",a3);
		}
    	
    	else if(a3 != 0){
    		printf("%.2fx",a3);
    	}
    }
    if(a4 < 0){
    	printf("%.2f",a4);
    }
    else{
    	if(a4 != 0){
    		printf("+%.2f",a4);
    	}
    }
    printf("\n");
}

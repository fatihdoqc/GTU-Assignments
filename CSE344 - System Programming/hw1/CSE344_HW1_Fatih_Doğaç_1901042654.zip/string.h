#ifndef STRCMP_H
#define STRCMP_H

int strcmpp(const char *s1, const char *s2);
int strln(const char* s1);
char* strchrr(const char *str, int character);
char* strtokk(char *str, char delimiter);
void  *my_memset(void *b, int c, int len);
char* strcpyy(char* destination, const char* source) ;

#endif 
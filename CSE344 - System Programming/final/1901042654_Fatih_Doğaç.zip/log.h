#ifndef LOG_H
#define LOG_H

#include <stdio.h>
#include <stdlib.h> 
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>

void log_it(char* ,char* str);

#endif
#ifndef UTILITIES_H
#define UTILITIES_H

struct order{
    int x;
    int y;
    pid_t pid;
    int p;
    int q;
    int orderCount;
    int cook;
    int delivery;
};


#endif